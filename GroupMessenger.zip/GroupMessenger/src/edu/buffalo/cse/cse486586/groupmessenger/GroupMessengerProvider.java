
package edu.buffalo.cse.cse486586.groupmessenger;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

public class GroupMessengerProvider extends ContentProvider {



    public static final Uri CONTENT_URI = Uri
            .parse("content://edu.buffalo.cse.cse486586.groupmessenger.provider");

    public static final String DATABASE = "myDb.db";

    public static final String TABLE_NAME = "myTable";

    public static final int DB_VERSION = 7;

    public static final String KEY = "key";

    public static final String VALUE = "value";

    private GmHelper gmHelper;

    private SQLiteDatabase sqlDb;

    private String CREATE_TABLE = String.format("CREATE TABLE %s "
            + "(%s text primary key, %s text)", GroupMessengerProvider.TABLE_NAME,
            GroupMessengerProvider.KEY, GroupMessengerProvider.VALUE);

    @Override
    public boolean onCreate() {

        gmHelper = new GmHelper(getContext());

        return false;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {

        sqlDb = gmHelper.getWritableDatabase();
        long id = sqlDb.insertWithOnConflict(TABLE_NAME, null, values,
                SQLiteDatabase.CONFLICT_REPLACE);

        if (id == -1) {
            return uri;
        } else {

            return ContentUris.withAppendedId(uri,id);
        }

    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs,
            String sortOrder) {

        String[] columns = {
                selection
        };
        sqlDb = gmHelper.getReadableDatabase();
        Cursor cursor = sqlDb.query(GroupMessengerProvider.TABLE_NAME, projection, "key=?",
                columns, null, null, sortOrder);

        return cursor;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {

        return 0;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {

        return 0;
    }

    @Override
    public String getType(Uri uri) {

        return null;
    }

    class GmHelper extends SQLiteOpenHelper {

        static final String TAG = "DBHelper";

        public GmHelper(Context context) {
            super(context, GroupMessengerProvider.DATABASE, null, GroupMessengerProvider.DB_VERSION);

        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // TODO Auto-generated method stub

            db.execSQL(CREATE_TABLE);

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub
            db.execSQL("drop table if exists " + GroupMessengerProvider.TABLE_NAME);
            onCreate(db);
        }

    }
}
