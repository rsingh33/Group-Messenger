
package edu.buffalo.cse.cse486586.groupmessenger;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.EditText;
import android.widget.TextView;

@SuppressLint("UseSparseArrays")
public class GroupMessengerActivity extends Activity {

    static final String TAG = "group";

    static final String REMOTE_PORT0 = "11108";

    static final String REMOTE_PORT1 = "11112";

    static final String REMOTE_PORT2 = "11116";

    static final String REMOTE_PORT3 = "11120";

    static final String REMOTE_PORT4 = "11124";

    static final int SERVER_PORT = 10000;

    static final int totSocks = 5;

    public static int avdNumber = 0;

    public static String AVD0 = "5554";

    public static String AVD1 = "5556";

    public static String AVD2 = "5558";

    public static String AVD3 = "5560";

    public static String AVD4 = "5562";

    public static String globalPort;

    String[] remotePort = {
            REMOTE_PORT0, REMOTE_PORT1, REMOTE_PORT2, REMOTE_PORT3, REMOTE_PORT4
    };

    private static final String KEY = "key";

    private static final String VALUE = "value";

    static String newMessage = "";

    static String divider = "-";

    static int messageKey = 0;

    static String messageValue = "";

    static String port;

    int localSeq = 0;

    static int lastMessageReceived = 0;

    Map<Integer, String> holdBack = new HashMap<Integer, String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_messenger);

        try {

            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
            return;
        }

        TextView tv = (TextView)findViewById(R.id.textView1);
        tv.setMovementMethod(new ScrollingMovementMethod());
        TelephonyManager tel = (TelephonyManager)this.getSystemService(Context.TELEPHONY_SERVICE);
        String portStr = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);

        final String myPort = String.valueOf((Integer.parseInt(portStr) * 2));
        port = portStr;
        globalPort = myPort;

        findViewById(R.id.editText1).setOnKeyListener(new OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN)
                        && (keyCode == KeyEvent.KEYCODE_ENTER)) {

                    final EditText editText1 = (EditText)findViewById(R.id.editText1);

                    String localMessage = editText1.getText().toString() + "\n";
                    editText1.setText(""); // Reset the editText

                    localMessage = localMessage + divider + "-1";
                    new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, localMessage,
                            myPort);

                    return true;
                }
                return false;
            }
        });

        findViewById(R.id.button1).setOnClickListener(
                new OnPTestClickListener(tv, getContentResolver()));

        findViewById(R.id.button4).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                final EditText editText = (EditText)findViewById(R.id.editText1);
                Log.d(TAG, "In Onclick View");
                String subMessage = editText.getText().toString();
                editText.setText("");
                subMessage = subMessage + divider + "-1";
                new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, subMessage, myPort);

                return;
            }
        });

    }

    public int getAvdNumber() {
        Log.d(TAG, "Assigning numbers to avds");

        if (port.equals(AVD0)) {

            avdNumber = 0;
            Log.d(TAG, "avd no is " + avdNumber);
        }
        if (port.equals(AVD1)) {
            avdNumber = 1;
            Log.d(TAG, "avd no is " + avdNumber);
        }
        if (port.equals(AVD2)) {
            avdNumber = 2;
            Log.d(TAG, "avd no is " + avdNumber);
        }
        if (port.equals(AVD3)) {
            avdNumber = 3;
            Log.d(TAG, "avd no is " + avdNumber);
        }
        if (port.equals(AVD4)) {
            avdNumber = 4;
            Log.d(TAG, "avd no is " + avdNumber);
        }
        return avdNumber;
    }

    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            String msg;

            try {
                while (true) {

                    Socket clientSocket = serverSocket.accept();
                    BufferedReader buffer = new BufferedReader(new InputStreamReader(
                            clientSocket.getInputStream()));
                    msg = buffer.readLine();
                    int msgNo = Integer.parseInt(msg.substring(msg.indexOf(divider) + 1));
                    messageValue = msg.substring(0, msg.indexOf(divider));
                    if (msgNo == -1) {
                        newMessage = messageValue + divider + localSeq++;
                        putMessage(newMessage);
                        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, newMessage,
                                globalPort);

                    } else if (msgNo == lastMessageReceived) {
                        putInContentProvider(msgNo, messageValue);
                        publishProgress(messageValue);
                        lastMessageReceived++;
                        traverseCompPut();
                    }
                    if (lastMessageReceived < localSeq) {
                        putMessage(msg);
                    }
                    buffer.close();
                    clientSocket.close();
                }
            } catch (IOException e) {
                System.out.println(e);
            }
            return null;

        }

        @Override
        protected void onProgressUpdate(String... strings) {
            Log.d(TAG, "In on progress Update Method");

            TextView tvs = (TextView)findViewById(R.id.textView1);
            tvs.append(strings[0] + "\n");
            return;

        }

        private Uri buildUri(String scheme, String authority) {
            Uri.Builder uriBuilder = new Uri.Builder();
            uriBuilder.authority(authority);
            uriBuilder.scheme(scheme);
            return uriBuilder.build();
        }

        protected void putInContentProvider(int key, String value) {

            Uri contentUri = buildUri("content",
                    "edu.buffalo.cse.cse486586.groupmessenger.provider");

            ContentValues values = new ContentValues();
            values.put(KEY, "" + key);
            values.put(VALUE, value);

            ContentResolver contentResolver = getContentResolver();
            contentResolver.insert(contentUri, values);
            Log.d(TAG, "the message is :" + values.toString());

        }

        public void putMessage(String msgValue) {
            int keyToPut = Integer.parseInt(msgValue.substring(msgValue.indexOf(divider) + 1));
            String valToPut = msgValue.substring(0, msgValue.indexOf(divider));
            holdBack.put(keyToPut, valToPut);
            traverseCompPut();
        }

        public void traverseCompPut() {
            while (!holdBack.isEmpty()) {
                if (lastMessageReceived != Collections.min(holdBack.keySet()))
                    break;
                publishProgress(holdBack.get(Collections.min(holdBack.keySet())));
                putInContentProvider(Collections.min(holdBack.keySet()),
                        holdBack.get(Collections.min(holdBack.keySet())));
                holdBack.remove(Collections.min(holdBack.keySet()));

                lastMessageReceived++;
            }
        }
    }

    private class ClientTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... msgs) {
            Log.d(TAG, "In Client");

            try {
                String msgToSend = msgs[0];

                int sequenceNumber = Integer.parseInt(msgToSend.substring(msgToSend
                        .indexOf(divider) + 1));
                if (sequenceNumber == -1) {
                    Socket socket = new Socket(InetAddress.getByAddress(new byte[] {
                            10, 0, 2, 2
                    }), Integer.parseInt(REMOTE_PORT0));
                    OutputStreamWriter out = new OutputStreamWriter(socket.getOutputStream());
                    BufferedWriter buffer = new BufferedWriter(out);
                    buffer.write(msgToSend);
                    buffer.flush();
                    socket.close();
                    Log.i(TAG, "Socket closed");

                }

                else {

                    for (int i = 0; i < totSocks; i++) {
                        Socket[] clientSocket = new Socket[totSocks];

                        clientSocket[i] = new Socket(InetAddress.getByAddress(new byte[] {
                                10, 0, 2, 2
                        }), Integer.parseInt(remotePort[i]));
                        Log.i(TAG, "Client socket created : " + clientSocket[i].toString());

                        OutputStreamWriter out = new OutputStreamWriter(
                                clientSocket[i].getOutputStream());
                        Log.i(TAG, "Output stream created : " + out.toString());

                        BufferedWriter buffer = new BufferedWriter(out);
                        Log.i("TAG", "Buffer Created : " + buffer.toString() + " , Message = "
                                + msgToSend);

                        buffer.write(msgToSend);
                        buffer.flush();
                        buffer.close();
                        clientSocket[i].close();
                        Log.i(TAG, "Socket closed");
                    }
                }
            } catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "ClientTask socket IOException" + e);
            }

            return null;
        }
    }
}
// Reference Concepts Discussed  with Ankit Sarraf